# Markdown document test

Kotin code placed in code blocks like the one below should be 
correctly highlighted.

``` kotlin
fun main(args: Array<String>) {
    println("Hello World!")
}
```